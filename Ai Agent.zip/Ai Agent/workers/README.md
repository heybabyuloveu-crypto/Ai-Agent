# Workers

This folder will contain GPU workers for LLM, image, and video pipelines, orchestrated using BullMQ.

## Worker Types

- `workers/llm/` — LLM worker code (e.g., for text generation, summarization)
- `workers/image/` — Stable Diffusion pipeline (e.g., for image generation, editing)
- `workers/video/` — Text-to-video pipeline (e.g., for video generation from text prompts)

## BullMQ Integration

Each worker type will have its own BullMQ queue for processing tasks. This allows for:
- **Decoupling:** Workers can process tasks independently of the main application.
- **Reliability:** Tasks are persistent and can be retried in case of failures.
- **Scalability:** Easily scale workers horizontally based on demand.
- **Monitoring:** BullMQ provides tools for monitoring queue status and worker performance.

## Next Steps

- Implement a basic BullMQ worker skeleton for a generic task.
- Create local development scripts to easily run and test workers.
- Define clear interfaces for task payloads and worker outputs.
