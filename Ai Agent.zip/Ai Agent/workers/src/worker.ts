import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import path from 'path';
import fs from 'fs';
import { S3Client, PutObjectCommand, CreateBucketCommand } from '@aws-sdk/client-s3';

const connection = { connection: { url: process.env.REDIS_URL || 'redis://127.0.0.1:6379' } };

// Configure S3/MinIO if provided
const S3_ENDPOINT = process.env.S3_ENDPOINT || process.env.MINIO_ENDPOINT;
const S3_BUCKET = process.env.S3_BUCKET || process.env.MINIO_BUCKET || 'ai-agent-outputs';
const S3_REGION = process.env.S3_REGION || 'us-east-1';
const S3_ACCESS_KEY = process.env.S3_ACCESS_KEY || process.env.MINIO_ACCESS_KEY;
const S3_SECRET_KEY = process.env.S3_SECRET_KEY || process.env.MINIO_SECRET_KEY;

let s3Client: S3Client | null = null;
if (S3_ENDPOINT && S3_ACCESS_KEY && S3_SECRET_KEY) {
  s3Client = new S3Client({
    region: S3_REGION,
    endpoint: S3_ENDPOINT,
    credentials: {
      accessKeyId: S3_ACCESS_KEY,
      secretAccessKey: S3_SECRET_KEY,
    },
    forcePathStyle: true,
  } as any);
}

// Helper to upload file to S3/MinIO
async function uploadToS3(localPath: string, key: string) {
  if (!s3Client) return null;
  try {
    // Ensure bucket exists (best-effort)
    try {
      await s3Client.send(new CreateBucketCommand({ Bucket: S3_BUCKET }));
    } catch (e) {
      // ignore if bucket exists or cannot be created
    }

    const fileStream = fs.createReadStream(localPath);
    await s3Client.send(new PutObjectCommand({ Bucket: S3_BUCKET, Key: key, Body: fileStream, ContentType: 'text/plain' }));
    // Construct a URL (works for MinIO default setup)
    const url = S3_ENDPOINT ? `${S3_ENDPOINT.replace(/\/$/, '')}/${S3_BUCKET}/${key}` : `s3://${S3_BUCKET}/${key}`;
    return url;
  } catch (err) {
    console.error('S3 upload error', err);
    return null;
  }
}

// Process 'generate:project' queue
const worker = new Worker(
  'generate:project',
  async (job) => {
    console.log('Processing job', job.id, job.name, job.data);

    // Simulate long-running generation task (replace with real generation)
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Create a placeholder output file under workers/output/<jobId>.txt
    const outDir = path.resolve(__dirname, '..', 'output');
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
    const outPath = path.join(outDir, `${job.id}.txt`);
    fs.writeFileSync(outPath, `Generated project for prompt:\n${JSON.stringify(job.data, null, 2)}`);

    // If S3 configured, upload the output and return s3Url
    let s3Url: string | null = null;
    if (s3Client) {
      const key = `${job.id}.txt`;
      s3Url = await uploadToS3(outPath, key);
    }

    console.log('Job complete, output written to', outPath, 's3Url=', s3Url);
    return { outPath, s3Url };
  },
  connection
);

worker.on('completed', (job) => {
  console.log(`Job ${job.id} completed`);
});

worker.on('failed', (job, err) => {
  console.error(`Job ${job?.id} failed:`, err);
});

console.log('Worker started for queue: generate:project');
