/**
 * BullMQ Worker for processing jobs from 'my-queue'
 * 
 * Initializes a worker that listens to a Redis queue and processes jobs asynchronously.
 * Handles job completion and failure events with appropriate logging.
 * 
 * @remarks
 * - The worker processes jobs from the 'my-queue' queue
 * - Logs job processing with job ID and associated data
 * - Tracks completed jobs and logs their completion status
 * - Tracks failed jobs and logs error messages
 * 
 * @example
 * ```typescript
 * // Worker automatically starts processing jobs from the queue
 * // Job data is logged to console upon processing
 * // Completion and failure events are monitored and logged
 * ```
 * 
 * @event completed - Fired when a job completes successfully
 * @event failed - Fired when a job fails with an error
 */
import { Worker, Job } from 'bullmq';

const worker = new Worker('my-queue', async (job: Job) => {
  console.log(`Processing job ${job.id} with data:`, job.data);
  // Your job processing logic here
});

worker.on('completed', (job: Job | undefined) => {
  const id = job?.id ?? 'unknown';
  console.log(`Job ${id} has completed!`);
});

worker.on('failed', (job: Job | undefined, err: unknown) => {
  const id = job?.id ?? 'unknown';
  const message = err instanceof Error ? err.message : String(err);
  console.log(`Job ${id} has failed with ${message}`);
});

console.log('Worker started');
