# Project Plan — Short

## Overview
This document summarizes the architecture, phases, and immediate next steps for the Full-Stack AI Agent Platform.

## Architecture
- Frontend: React + TypeScript + Tailwind + Monaco
- API Gateway: Node + Fastify (Auth, rate-limit)
- Queue: Redis + BullMQ
- Workers: GPU workers for LLM / SD / video
- Storage: S3 / MinIO
- DB: PostgreSQL (metadata)

## Immediate Phases
1. UI mock + basic chat streaming (Phase 1)
2. API + JWT + API Key (Phase 2)
3. LLM integration + local model tests (Phase 3)

## Next dev tasks (short-term)
- Create minimal `backend/src/index.ts` that returns a health check
- Create `frontend` placeholder with a chat mock page
- Add CI: linter + basic test job

