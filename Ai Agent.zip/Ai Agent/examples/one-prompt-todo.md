# One-Prompt Example — Full-Stack Todo App

Prompt:

> "Create a full-stack todo app with React + Node + Express, Postgres for storage, and a simple UI with add/remove tasks. Include Dockerfiles and a script to run `npm install` and start both frontend and backend."

Expected outcome (one-prompt generator):
- Generates a ZIP containing `frontend/` and `backend/` folders
- `frontend/` contains a React app with Tailwind and a Todo page
- `backend/` contains an Express API with `/api/todos` endpoints
- Root contains `docker-compose.yml` and README with `install` and `start` commands
