import Fastify, { FastifyRequest, FastifyReply } from 'fastify';
// If @fastify/cors types are not installed, import via require and cast to any
// to avoid TypeScript module-not-found errors in environments without type defs.
// @ts-ignore
const cors: any = require('@fastify/cors');
import { authGuard, validApiKeys } from './auth';
import projectQueue from './queue';

const server = Fastify({ logger: true });

// SSE configuration (tunable via environment)
const SSE_MAX_TOKENS = Number(process.env.SSE_MAX_TOKENS) || 2000;
const SSE_MAX_DURATION_MS = Number(process.env.SSE_MAX_DURATION_MS) || 30_000;


// Enable CORS
server.register(cors, {
  origin: [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    'http://localhost:3000'
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
});

// Health check
server.get('/health', async () => ({ ok: true }));

// Simple mock chat endpoint (replace with real model streaming later)
server.post('/api/v1/chat', async (request: FastifyRequest, reply: FastifyReply) => {
  const body = request.body as any || {};
  const model = body.model || 'mock';
  const prompt = body.prompt || '';

  // Simple response; later this will enqueue a job and stream tokens
  return {
    model,
    prompt,
    response: `Echo (mock): ${prompt}`,
    streamed: false
  };
});

// SSE endpoint for token-by-token streaming (Phase 3+)
server.get('/api/v1/chat/stream', { onRequest: [authGuard] }, async (request: FastifyRequest, reply: FastifyReply) => {
  const { prompt = '' } = (request.query as any) || {};

  reply.type('text/event-stream');
  reply.header('Cache-Control', 'no-cache');
  reply.header('Connection', 'keep-alive');

  const raw = reply.raw;
  let clientAborted = false;
  const onClose = () => { clientAborted = true; };
  // Listen for client disconnects to avoid resource leaks
  request.raw.on('close', onClose);

  // Safety limits
  const maxTokens = SSE_MAX_TOKENS;
  const maxDurationMs = SSE_MAX_DURATION_MS; // ms
  const startTime = Date.now();

  // Simulate streaming tokens
  const mockResponse = `This is a mock streamed response to: "${prompt}". Each word comes token by token.`;
  const tokens = mockResponse.split(' ');

  try {
    let sent = 0;
    for (const token of tokens) {
      if (clientAborted) break;
      if (Date.now() - startTime > maxDurationMs || sent >= maxTokens) {
        // send a final event indicating the stream ended due to limit
        const payload = { token: '', done: true, reason: 'limit', error: null };
        try { raw.write(`data: ${JSON.stringify(payload)}\n\n`); } catch (e) { }
        break;
      }

      // write token event using stable payload shape
      try {
        const payload = { token, done: false, reason: null, error: null };
        raw.write(`data: ${JSON.stringify(payload)}\n\n`);
      } catch (e) {
        // If write fails, stop streaming
        break;
      }

      sent += 1;
      // Simulate network delay between tokens
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  } catch (err) {
    // Log and attempt to notify client of error
    request.log?.error?.(err);
    try {
      if (!raw.writableEnded && !clientAborted) {
        const payload = { token: '', done: true, reason: 'error', error: 'internal_server_error' };
        raw.write(`data: ${JSON.stringify(payload)}\n\n`);
      }
    } catch (e) { }
  } finally {
    // Clean up: end the response only if it hasn't already been ended and client still connected
    try {
      if (!raw.writableEnded && !clientAborted) raw.end();
    } catch (e) {
      // ignore
    }
    request.raw.off('close', onClose);
  }
});

// Enqueue a project generation job
server.post('/api/v1/generate/project', async (request: FastifyRequest, reply: FastifyReply) => {
  const body = request.body as any || {};
  const prompt = body.prompt || '';
  const stack = body.stack || ['react', 'node'];
  const deploy = body.deploy || 'local';

  try {
  const job = await projectQueue.add('job', { prompt, stack, deploy }, { removeOnComplete: true, removeOnFail: 100 });
  return { ok: true, jobId: job.id };
  } catch (err) {
  request.log.error(err);
  return reply.code(500).send({ ok: false, error: 'failed to enqueue job' });
  }
});

// Job status endpoint
server.get('/api/v1/jobs/:id', async (request: FastifyRequest, reply: FastifyReply) => {
  const id = ((request.params as any) || {}).id;
  try {
    const job = await projectQueue.getJob(id);
    if (!job) return reply.code(404).send({ ok: false, error: 'job not found' });

    const state = await job.getState();
    const returnvalue = job.returnvalue || null;

    // If returnvalue contains s3Url, include it as downloadUrl
    const downloadUrl = returnvalue && (returnvalue as any).s3Url ? (returnvalue as any).s3Url : null;

    return { ok: true, id: job.id, name: job.name, state, returnvalue, downloadUrl };
  } catch (err) {
    request.log.error(err);
    return reply.code(500).send({ ok: false, error: 'failed to fetch job status' });
  }
});

const start = async () => {
  try {
    // Log API key configuration at startup using Fastify logger for observability
    if (validApiKeys.size === 0) {
      if (process.env.NODE_ENV !== 'development') {
        server.log.warn('Warning: VALID_API_KEYS is not configured — API-key-based auth is disabled.');
      } else {
        server.log.debug('DEV: VALID_API_KEYS not set — API-key auth disabled (development mode).');
      }
    } else {
      server.log.debug(`Loaded ${validApiKeys.size} API key(s) from VALID_API_KEYS`);
    }
    await server.listen({ port: 3000, host: '0.0.0.0' });
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
};

start();
