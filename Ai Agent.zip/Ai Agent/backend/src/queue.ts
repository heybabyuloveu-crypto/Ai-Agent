import { Queue } from 'bullmq';

// Use REDIS_URL env or default to localhost. Provide an explicit typed variable to satisfy
// TypeScript strict checks when @types/node is available.
const redisUrl: string = process.env.REDIS_URL ?? 'redis://127.0.0.1:6379';
const connection = { connection: { url: redisUrl } };

export const projectQueue = new Queue('generate:project', connection as any);

export default projectQueue;
