import jwt from 'jsonwebtoken';


// Minimal local typings to avoid requiring the 'fastify' module/types during
// type-checking in environments where Fastify isn't installed. This keeps the
// runtime behavior unchanged while resolving the TS error: "Cannot find
// module 'fastify' or its corresponding type declarations." If you have
// Fastify available in your project, you can restore the original import.
interface FastifyRequest {
  headers: Record<string, string | undefined>;
  // jwtVerify is provided by fastify-jwt plugin; include as optional to
  // support projects that may not load that plugin at type-check time.
  jwtVerify?: () => Promise<void>;
  user?: {
    userId: string;
    apiKey?: string;
  };
}

interface FastifyReply {
  code: (status: number) => { send: (payload: any) => void };
  send: (payload: any) => void;
}

/**
 * Simple API Key + JWT auth decorator for Fastify
 * Phase 3: Protected endpoints require either:
 * 1. Bearer JWT token in Authorization header
 * 2. X-API-Key header with a valid API key
 */

// --- Constants for Headers ---
const AUTH_HEADER = 'authorization';
const API_KEY_HEADER = 'x-api-key';
const BEARER_PREFIX = 'Bearer ';

// --- Configuration ---
// Load valid API keys from environment variables for better security and configuration.
// Example: VALID_API_KEYS="key1,key2,key3"
const rawKeys = ((process.env.VALID_API_KEYS || '').split(',') as string[])
  .map((k: string) => k.trim())
  .filter(Boolean);
const validApiKeys = new Set<string>(rawKeys);

// Note: module-level logging is intentionally removed so that the application
// can control observability via the Fastify logger. The `validApiKeys` set is
// exported so the server can log its state at startup using `server.log`.
export { validApiKeys };

// Note: we intentionally avoid augmenting the 'fastify' module here to
// prevent the TypeScript error when Fastify types are not installed.

/**
 * Authentication guard for Fastify routes.
 * Verifies the presence and validity of a JWT or an API key.
 * @param {FastifyRequest} request - The incoming request object.
 * @param {FastifyReply} reply - The reply object.
 */
export async function authGuard(request: FastifyRequest, reply: FastifyReply) {
  const authHeader = request.headers[AUTH_HEADER];
  const apiKey = request.headers[API_KEY_HEADER] as string;

  // 1. Check for JWT Bearer token
    if (authHeader?.startsWith(BEARER_PREFIX)) {
      // Ensure jwtVerify exists and is callable to avoid runtime errors
      const jwtVerify = (request as any).jwtVerify;
      if (typeof jwtVerify !== 'function') {
        // jwtVerify not configured on this Fastify instance
        return reply.code(401).send({ error: 'JWT verification not configured' });
      }

      try {
        // call the configured jwtVerify
        await jwtVerify.call(request);
        // JWT is valid, continue
        return;
      } catch (err) {
        // Controlled 401 response for invalid JWT
        return reply.code(401).send({ error: 'Invalid JWT token' });
      }
    }

  // 2. Check for API Key
  if (apiKey && validApiKeys.has(apiKey)) {
    // Valid API key, attach user info to the request for downstream use.
    request.user = { userId: 'api-user', apiKey };
    return;
  }

  // 3. No valid authentication method found
  return reply.code(401).send({ error: 'Unauthorized: A valid JWT or API Key is required' });
}

/**
 * Generates a mock JWT for testing and development purposes.
 * In a real application, the secret should be stored securely.
 * @param {string} userId - The user ID to include in the token payload.
 * @param {string} secret - The secret key for signing the token.
 * @returns {string} A signed JWT.
 */
export function generateMockJWT(userId: string, secret: string): string {
  const payload = { userId };
  return jwt.sign(payload, secret);
}
