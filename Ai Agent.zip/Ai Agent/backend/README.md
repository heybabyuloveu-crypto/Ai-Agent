# Backend

Node.js + TypeScript + Fastify API gateway with CORS, SSE streaming, and JWT + API Key auth.

## Features

- **Fastify** — Fast, low-overhead HTTP server
- **CORS** — Enabled for local development (Vite frontend)
- **SSE Streaming** — Token-by-token responses via `GET /api/v1/chat/stream`
- **Auth** — JWT Bearer tokens + API Key headers (Phase 3)
- **Extensible** — Ready for BullMQ + Redis queue integration

## Endpoints

- `GET /health` — Health check
- `POST /api/v1/chat` — Mock chat (no auth required)
- `GET /api/v1/chat/stream` — Streaming chat response (auth required)
  - Query: `prompt=...`
  - Auth: `Authorization: Bearer <jwt>` or `X-API-Key: <key>`

## Auth

Protected endpoints require one of:
1. **JWT Bearer Token**: `Authorization: Bearer eyJhb...`
2. **API Key Header**: `X-API-Key: sk-demo-key-12345`

Mock API keys:
- `sk-demo-key-12345`
- `sk-dev-key-abcde`

## Run locally (development)

```powershell
npm install
npm run dev
```

Backend listens on port `3000`. CORS is enabled for `http://localhost:5173` (Vite frontend).

## Build + start (production-like)

```powershell
npm run build
npm start
```

## Next steps

- Integrate BullMQ + Redis for async job processing
- Replace mock streaming with real LLM pipeline
- Add rate limiting and request logging
