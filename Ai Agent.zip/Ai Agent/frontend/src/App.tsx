import React, { useState, useRef, useEffect } from 'react'
import { Editor } from '@monaco-editor/react'

type Message = { from: 'user' | 'bot'; text: string }

export default function App() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<Message[]>([])
  const [streaming, setStreaming] = useState(false)
  const [codePreview, setCodePreview] = useState('// Code output will appear here\nconsole.log("Hello, AI Agent!");')
  const chatEndRef = useRef<HTMLDivElement>(null)

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const send = async () => {
    if (!input.trim()) return
    const prompt = input.trim()
    setMessages((m) => [...m, { from: 'user', text: prompt }])
    setInput('')

    // Add placeholder for bot response
    setMessages((m) => [...m, { from: 'bot', text: '' }])
    setStreaming(true)
    setCodePreview('// Processing...')

    try {
      const response = await fetch(`http://localhost:3000/api/v1/chat/stream?prompt=${encodeURIComponent(prompt)}`)
      
      if (!response.ok) throw new Error('Backend error')

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader!.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')

        for (let i = 0; i < lines.length - 1; i++) {
          const line = lines[i].trim()
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6))
              if (data.token) {
                setMessages((prev) => {
                  const copy = [...prev]
                  const lastIdx = copy.map((x) => x.from).lastIndexOf('bot')
                  if (lastIdx >= 0) {
                    copy[lastIdx] = {
                      from: 'bot',
                      text: copy[lastIdx].text + data.token + ' '
                    }
                  }
                  return copy
                })
              }
              if (data.done) {
                setStreaming(false)
                // Update code preview with response snippet
                setCodePreview(`// Response:\n${messages[messages.length - 1]?.text || ''}`)
              }
            } catch (e) {
              // SSE parse error, continue
            }
          }
        }
        buffer = lines[lines.length - 1]
      }
    } catch (err) {
      setMessages((m) => [...m, { from: 'bot', text: 'Error: could not reach backend' }])
      setStreaming(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-100">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-700 px-6 py-4">
        <h1 className="text-2xl font-bold">AI Agent Platform</h1>
        <p className="text-xs text-slate-400 mt-1">Chat • Code Preview • Streaming Responses</p>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden gap-4 p-4">
        {/* Chat Pane */}
        <div className="flex-1 flex flex-col bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-3 flex flex-col">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex ${m.from === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg whitespace-pre-wrap text-sm ${
                    m.from === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-800 text-slate-100 border border-slate-700'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-slate-700 p-4 bg-slate-800">
            <div className="flex gap-2">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type your prompt (Shift+Enter for new line)..."
                rows={2}
                className="flex-1 bg-slate-700 text-slate-100 border border-slate-600 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              />
              <button
                onClick={send}
                disabled={streaming || !input.trim()}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold px-4 py-2 rounded transition"
              >
                {streaming ? 'Streaming...' : 'Send'}
              </button>
            </div>
          </div>
        </div>

        {/* Code Preview Pane */}
        <div className="flex-1 bg-slate-900 rounded-lg border border-slate-700 overflow-hidden flex flex-col">
          <div className="bg-slate-800 border-b border-slate-700 px-4 py-3">
            <h2 className="text-sm font-semibold">Code Preview</h2>
          </div>
          <div className="flex-1 overflow-hidden">
            <Editor
              height="100%"
              defaultLanguage="javascript"
              value={codePreview}
              onChange={(val) => setCodePreview(val || '')}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 12,
                lineNumbers: 'on',
                scrollBeyondLastLine: false,
                automaticLayout: true
              }}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
