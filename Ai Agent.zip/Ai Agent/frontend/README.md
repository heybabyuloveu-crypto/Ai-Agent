# Frontend

React + TypeScript + Vite frontend with Tailwind CSS styling and Monaco Editor for code preview.

## Features

- **Chat UI** — Clean, modern interface with message history
- **SSE Streaming** — Displays real-time token-by-token responses from the backend
- **Code Preview** — Monaco Editor pane to display code output
- **Tailwind CSS** — Responsive, utility-first styling
- **Hot Reload** — Vite dev server with instant updates

## Run locally

```powershell
npm install
npm run dev
```

Then open `http://localhost:5173` in your browser.

## Build

```powershell
npm run build
npm preview
```

## Tech

- React 18 + TypeScript
- Vite (dev server & build)
- Tailwind CSS
- Monaco Editor
- Server-Sent Events (SSE) for streaming
